export default {
	// 可以以页面为单位来写，比如首页的内容，写在index字段，个人中心写在center，共同部分写在common部分
	tabbar: {
		component: '组件',
		js: '工具',
		template: '模板'
	},
	js: {
		desc: '工具'
	},
	component: {
		desc: '组件'
	},
	template: {
		desc: '模板'
	}
}